﻿using OkosotthonErtesites.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OkosotthonErtesites
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //5. feladat: Értesítés
            List<Ertesites> csatornak = new List<Ertesites>
        {
            new PushErtesites("PHONE-0123"),
            new EmailErtesites("tulajdonos@okosotthon.hu", "Rendszerriasztás"),
            new SmsErtesito("+36301234567")
        };

            string riasztasUzenet = "Figyelem! Mozgás érzékelve a nappaliban!";

            foreach (var csatorna in csatornak)
            {
                csatorna.Kuld(riasztasUzenet, DateTime.Now);
            }
        }
    }
}
