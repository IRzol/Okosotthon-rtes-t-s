﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OkosotthonErtesites.Models
{
    public abstract class Ertesites
    {
        public abstract void Kuld(string uzenet, DateTime idobelyeg);
    }
}
