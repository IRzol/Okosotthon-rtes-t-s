﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OkosotthonErtesites.Models
{
    public class EmailErtesites:Ertesites
    {
        public EmailErtesites(string emailCim, string targy)
        {
            Targy = targy;
            EmailCim = emailCim;
        }

        public string EmailCim { get; set; }
        public string Targy { get; set; }
        

        public override void Kuld(string uzenet, DateTime idobelyeg)
        {
            Console.WriteLine($"Email: {EmailCim}, Tárgy: {Targy}, Üzenet: {uzenet}, Ideje: {idobelyeg}");
        }
    }
}
