﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OkosotthonErtesites.Models
{
    public class SmsErtesito : Ertesites
    {
        public string Telefonszam { get; set; }

        public SmsErtesito(string telefonszam)
        {
            Telefonszam = telefonszam;
        }

        public override void Kuld(string uzenet, DateTime idobelyeg)
        {
            Console.WriteLine($"SMS [{Telefonszam}]: {uzenet}, {idobelyeg}");
        }
    }
}
