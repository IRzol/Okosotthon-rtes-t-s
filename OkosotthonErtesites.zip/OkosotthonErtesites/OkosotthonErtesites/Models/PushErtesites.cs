﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OkosotthonErtesites.Models
{
    public class PushErtesites: Ertesites
    {
        public string EszkozAzonosito { get; set; }

        public PushErtesites(string eszkozAzonosito)
        {
            EszkozAzonosito = eszkozAzonosito;
        }

        public override void Kuld(string uzenet, DateTime idobelyeg)
        {
            Console.WriteLine($"PUSH [{EszkozAzonosito}]: {uzenet}, {idobelyeg}");
        }
    }
}
